open Parser
open Quadtree

let load_city_data (s:string) : string quadtree = failwith "TODO"

let city_search (q: string quadtree) (r : region) : string list = 
	failwith "TODO"
